"""
notebooks/01_demo_and_eval.py
Evaluation script: compares YOLO-only baseline vs full pipeline.
Run with:  python notebooks/01_demo_and_eval.py --video path/to/clip.mp4
"""

import os, sys, cv2, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import config
from src.detector  import FaceDetector
from src.tracker   import FaceTracker
from src.embedder  import FaceEmbedder
from src.reid      import ReIDEngine


def run_baseline_yolo_only(video_path: str, max_frames: int = 500):
    """
    YOLO-only baseline: just count unique track IDs (no re-ID).
    Identity switches = new track IDs generated unnecessarily.
    """
    detector = FaceDetector()
    tracker  = FaceTracker()

    cap = cv2.VideoCapture(video_path)
    all_ids   = set()
    frame_idx = 0

    while frame_idx < max_frames:
        ret, frame = cap.read()
        if not ret: break
        if frame_idx % config.FRAME_SKIP != 0:
            frame_idx += 1; continue

        frame = cv2.resize(frame, (config.RESIZE_WIDTH, config.RESIZE_HEIGHT))
        boxes, scores, _ = detector.detect(frame)
        tracks = tracker.update(frame, boxes, scores)
        for t in tracks:
            all_ids.add(t["track_id"])
        frame_idx += 1

    cap.release()
    return {"unique_track_ids": len(all_ids), "method": "YOLO+DeepSORT only"}


def run_full_pipeline(video_path: str, max_frames: int = 500):
    """Run the full pipeline with Re-ID re-scoring."""
    detector = FaceDetector()
    tracker  = FaceTracker()
    embedder = FaceEmbedder()
    reid     = ReIDEngine(embedder)

    cap = cv2.VideoCapture(video_path)
    frame_idx = 0

    while frame_idx < max_frames:
        ret, frame = cap.read()
        if not ret: break
        if frame_idx % config.FRAME_SKIP != 0:
            frame_idx += 1; continue

        frame = cv2.resize(frame, (config.RESIZE_WIDTH, config.RESIZE_HEIGHT))
        boxes, scores, _ = detector.detect(frame)
        tracks = tracker.update(frame, boxes, scores)
        for t in tracks:
            x1,y1,x2,y2 = t["bbox"]
            crop = frame[max(0,y1):y2, max(0,x1):x2]
            reid.process_track(t["track_id"], crop)
        frame_idx += 1

    cap.release()
    return {
        "unique_identities":     len(reid.gallery),
        "re_identifications":    reid.stats["reidentifications"],
        "switches_prevented":    reid.stats["identity_switches_prevented"],
        "method": "Full pipeline (YOLO+DeepSORT+DeepFace+ReID)"
    }


def compute_identity_switch_reduction(baseline: dict, full: dict) -> float:
    """
    Estimate identity-switch reduction.
    Baseline unique track IDs >> actual people = excess IDs = switches.
    """
    # In a perfect tracker with N real people, we should see N unique IDs.
    # Extra track IDs beyond actual identities ≈ identity switches.
    expected_actual = full["unique_identities"]
    baseline_excess  = max(0, baseline["unique_track_ids"] - expected_actual)
    full_excess      = max(0, expected_actual - expected_actual)  # 0 ideally
    if baseline_excess == 0:
        return 0.0
    return round((baseline_excess - full["switches_prevented"]) / baseline_excess * 100, 1)


def visualise_comparison(baseline: dict, full: dict):
    fig, axes = plt.subplots(1, 2, figsize=(12, 5), dpi=120)

    # Metric comparison
    metrics = ["unique_track_ids / identities", "switches_prevented"]
    b_vals  = [baseline["unique_track_ids"], 0]
    f_vals  = [full["unique_identities"],    full["switches_prevented"]]
    x = np.arange(len(metrics))
    axes[0].bar(x - 0.2, b_vals, 0.35, label="Baseline (YOLO only)", color="#DD8452")
    axes[0].bar(x + 0.2, f_vals, 0.35, label="Full pipeline",         color="#4C72B0")
    axes[0].set_xticks(x); axes[0].set_xticklabels(metrics, fontsize=9)
    axes[0].set_title("Baseline vs Full Pipeline"); axes[0].legend()
    axes[0].grid(axis="y", alpha=0.4)

    # Reduction pie
    prevented = full["switches_prevented"]
    remaining = max(0, baseline["unique_track_ids"] - full["unique_identities"] - prevented)
    axes[1].pie([prevented, max(0, remaining)],
                labels=[f"Prevented\n({prevented})", f"Remaining\n({remaining})"],
                colors=["#55A868", "#DD8452"], autopct="%1.0f%%", startangle=90)
    axes[1].set_title("Identity Switch Reduction")

    plt.tight_layout()
    os.makedirs("outputs", exist_ok=True)
    plt.savefig("outputs/eval_comparison.png", bbox_inches="tight")
    plt.show()
    print("Eval plot → outputs/eval_comparison.png")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--video",      default="data/videos/test.mp4")
    parser.add_argument("--max-frames", type=int, default=500)
    args = parser.parse_args()

    print("=== Running YOLO-only baseline ===")
    baseline = run_baseline_yolo_only(args.video, args.max_frames)
    print(json.dumps(baseline, indent=2))

    print("\n=== Running Full Pipeline ===")
    full = run_full_pipeline(args.video, args.max_frames)
    print(json.dumps(full, indent=2))

    pct = compute_identity_switch_reduction(baseline, full)
    print(f"\nEstimated switch reduction: {pct:.1f}%")
    print(f"(Target: ~70% — paper result)")

    visualise_comparison(baseline, full)
