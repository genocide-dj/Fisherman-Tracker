#!/bin/bash
# Run this first to create all directories
mkdir -p data/videos data/annotations models logs outputs
mkdir -p src dashboard notebooks
echo "✅ Project structure created"
